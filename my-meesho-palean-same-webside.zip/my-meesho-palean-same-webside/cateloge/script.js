// Zoom effect for product images
const zoomImages = document.querySelectorAll('.zoomable');
zoomImages.forEach(img => {
  img.addEventListener('click', () => {
    img.classList.toggle('zoomed');
  });
});

// Scroll to products on "Shop Now"
document.getElementById('shopNowBtn').addEventListener('click', () => {
  document.querySelector('#products').scrollIntoView({ behavior: 'smooth' });
});

// Add to cart functionality
const cartButtons = document.querySelectorAll('.add-to-cart');
cartButtons.forEach(button => {
  button.addEventListener('click', () => {
    alert('Item added to cart 🛒');
  });
});
